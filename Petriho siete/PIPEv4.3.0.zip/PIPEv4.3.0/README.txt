Functionality enhancement: 
	Functional transition rates and functional arc weights.

New feature: Infinite-server semantics. 

Bug fixing: 
	state space exploration bug; 
	Import from eDSPN file bug temporal fix;
	deleting Petri net component bug.

