#!/bin/bash
cd Pipe
java -classpath .:./lib/jpowergraph-0.2-common.jar:./lib/jpowergraph-0.2-swing.jar:./lib/powerswing-0.3.jar:./lib/drmaa.jar:./lib/hadoop-0.13.1-dev-core.jar:./lib/jcommon-1.0.10.jar:./lib/jfreechart-1.0.6.jar:./lib/jfreechart-1.0.6-swt.jar:./lib/tools.jar:.lib/jeval.jar Pipe